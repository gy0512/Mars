﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecflowPages
{
    public class ConstantUtils
    {
        //Base Url
        public static string Url = "http://www.skillswap.pro/";

        //ScreenshotPath
        public static string ScreenshotPath = @"G:\IC_Projects\Mars\SpecflowTests-Base\SpecflowTests\SpecflowPages\TestReports\Screenshots\";

        //ExtentReportsPath
        public static string ReportsPath = @"G:\IC_Projects\Mars\SpecflowTests-Base\SpecflowTests\SpecflowPages\TestReports\Test.html";

        //ReportXML Path
        public static string ReportXMLPath = @"G:\IC_Projects\Mars\SpecflowTests-Base\SpecflowTests\SpecflowPages\TestReports\ReportXML.xml";



    }
}
